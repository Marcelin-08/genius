package br.com.curso.genius

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val sequenciaComputador = mutableListOf<Int>()
    private var passoJogador = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    private fun adicionarNovaCor() {
        val novaCor = (0..3).random()
        sequenciaComputador.add(novaCor)
        mostrarSequencia()
    }

    private fun mostrarSequencia() {
        println("Sequência: $sequenciaComputador")
    }

    private fun verificarJogada(corClicada: Int) {
        if (sequenciaComputador.isEmpty()) return

        if (corClicada == sequenciaComputador[passoJogador]) {
            passoJogador++

            if (passoJogador == sequenciaComputador.size) {
                passoJogador = 0
                adicionarNovaCor()
            }
        } else {
            println("GAME OVER! Pontuação: ${sequenciaComputador.size - 1}")
            sequenciaComputador.clear()
            passoJogador = 0
        }
    }
}